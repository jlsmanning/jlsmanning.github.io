import cv2 as cv
import matplotlib.pyplot as plt
import os

import align
import borders
import enhance
import result_to_html
from helpers import *

def do_crop(img, stem):
    # crop white border
    img = borders.crop_white_border(img, stem)
    if stem in ["01728v", "01269v"]:
        return img    
    # crop black outer border
    img = borders.crop_outer_black_border(img, stem)        
    # crop black inner borders
    img = borders.crop_inner_black_border(img, stem)
    return img

def do_align(img, stem):
    # divide image into channels
    b, g, r = thirds(img)
    save_image(merge_image(b,g,r), stem, "before_align")

    # prep channels into versions used for alignment
    b_edge, g_edge, r_edge = align.preprocess(b), align.preprocess(g), align.preprocess(r)
    save_image(sidebyside(b_edge, g_edge, r_edge), stem, "channels_edges")

    # find best x,y alignments for edge channels (scale? rotation?)
    #r_best_tx, r_best_ty = align.exhaustive_align(g_edge, r_edge, stem)
    #b_best_tx, b_best_ty = align.exhaustive_align(g_edge, b_edge, stem)
    r_best_tx, r_best_ty = align.pyramid_align(g_edge, r_edge, stem)
    b_best_tx, b_best_ty = align.pyramid_align(g_edge, b_edge, stem)

    # apply alignments to channels
    r = shift(r, r_best_tx, r_best_ty)
    b = shift(b, b_best_tx, b_best_ty)
    save_image(merge_image(b, g, r), stem, "aligned")

    # crop out the stripes created by displacement
    # (probably this would have gotten rid of the inner black borders)
    b, g, r = borders.crop_displacement_stripes(b, g, r,
                                                b_best_tx,
                                                b_best_ty,
                                                r_best_tx,
                                                r_best_ty)
    img = merge_image(b, g, r)
    save_image(img, stem, "cropaligned")
    return img

def restore(filename):
    print(filename)
    # load image
    img, stem = load_image(filename)
    save_image(img, stem, "orig")

    align_path = os.path.join(RESULTS_DIR, stem,
                              stem + '_cropaligned.png')
    if not os.path.exists(align_path):
        img = do_crop(img, stem)
        img = do_align(img, stem)
    else:
        img = cv.imread(align_path, cv.IMREAD_COLOR)        

    if VERBOSEP:
        print("tweaking colors a bit")

    #show_image(img)
    img = enhance.gamma(img, gamma=0.8)
    save_image(img, stem, "gamma")
    #show_image(img)

    img = enhance.equalize(img)
    save_image(img, stem, "equalize")
    #show_image(img)
    
    img = enhance.scale(img, 1.1, 0)
    save_image(img, stem, "contrast")

    save_image(img, stem, "final")
    return img

if __name__=="__main__":
    #restore("00125v.jpg")
    #exit()
    #restore("01861a.jpg")
    #exit()
    files = get_files(which='all')
    #files = ["10131v.jpg", "01522v.jpg"]
    for f in files:
        img = restore(f)
        result_to_html.build(f)




