import cv2 as cv

from helpers import *

def white_balance(b, g, r):
    max_intensity = 0
    max_y = 0
    max_x = 0
    # find the brightest pixel
    for i in range(b.shape[0]):
        for j in range(b.shape[1]):
            intensity = float(b[i,j]) + float(g[i,j]) + float(r[i,j])
            if intensity > max_intensity:
                max_intensity = intensity
                max_y = i
                max_x = j
    b = to_uint8(to_float(b) * (255 / float(b[max_y, max_x])))
    g = to_uint8(to_float(g) * (255 / float(g[max_y, max_x])))
    r = to_uint8(to_float(r) * (255 / float(r[max_y, max_x])))
    return b, g, r

def mean_white_balance(img):
    channels = cv.split(img)
    results = []
    for i in range(3):
        mu = channels[i].mean()
        c = channels[i].astype('float32') / mu
        c = c.clip(0, 1)
        c = to_uint8(c)
        results.append(c)
    img = cv.merge((results[0], results[1], results[2]))
    return img

# def percentile_white_balance(b, g, r, pval=99):
#     # https://jephraim-manansala.medium.com/image-processing-with-python-color-correction-using-white-balancing-6c6c749886de
#     channels = [b,g,r]
#     for i in range(3):
#         val = np.percentile(channels[c], pval)
        
def gamma(img, gamma=1.0):
    # https://www.pyimagesearch.com/2015/10/05/opencv-gamma-correction/
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255
		      for i in np.arange(0, 256)]).astype("uint8")
    img = cv.LUT(img, table)
    return img

def equalize(img):
    # this is bad!
    # b = cv.equalizeHist(b)
    # g = cv.equalizeHist(g)
    # r = cv.equalizeHist(r)
    # this is better!
    # https://stackoverflow.com/questions/15007304/histogram-equalization-not-working-on-color-image-opencv
    img = cv.cvtColor(img, cv.COLOR_BGR2YCrCb)
    channels = list(cv.split(img))
    channels[0] = cv.equalizeHist(channels[0])
    channels = tuple(channels)
    cv.merge(channels, img)
    img = cv.cvtColor(img, cv.COLOR_YCrCb2BGR)
    return img

def denoise(b, g, r):
    # https://docs.opencv.org/4.x/d5/d69/tutorial_py_non_local_means.html
    # b = cv.fastNlMeansDenoising(b, None, 10, 7, 21)
    # g = cv.fastNlMeansDenoising(g, None, 10, 7, 21)
    # r = cv.fastNlMeansDenoising(r, None, 10, 7, 21)
    img = merge_image(b, g, r)
    img = cv.fastNlMeansDenoisingColored(img, None, 3, 10, 7, 21)
    channels = cv.split(img)
    b = channels[0]
    g = channels[1]
    r = channels[2]
    return b, g, r

def scale(c, alpha, beta):
    c = cv.convertScaleAbs(c, alpha=alpha, beta=beta)
    return c
    
