import cv2 as cv

from helpers import *

def preprocess(c):
    if VERBOSEP:
        print("preprocessing channel for alignment")
    # normalize
    n = to_uint8(normalize(c))
    # despeckle/blur
    b = cv.medianBlur(n,5)
    # get gradient
    #g = cv.Laplacian(b, cv.CV_64F)
    #g = cv.Canny(image=b, threshold1=100, threshold2=200)
    # https://docs.opencv.org/3.4/d2/d2c/tutorial_sobel_derivatives.html
    grad_x = cv.Sobel(b, cv.CV_16S, 1, 0, ksize=3, scale=1,
                      delta=0, borderType=cv.BORDER_DEFAULT)
    grad_y = cv.Sobel(b, cv.CV_16S, 0, 1, ksize=3, scale=1,
                      delta=0, borderType=cv.BORDER_DEFAULT)
    abs_grad_x = cv.convertScaleAbs(grad_x)
    abs_grad_y = cv.convertScaleAbs(grad_y)   
    g = cv.addWeighted(abs_grad_x, 0.5, abs_grad_y, 0.5, 0)
    return g

def exhaustive_align(a, b, stem, max_dp=20, offset=[0,0],
                     win_ratio=0.8):
    a_center = subsample_center(a, ratio=win_ratio)
    b_center = subsample_center(b, ratio=win_ratio)
    best_error = ssd(a_center, b_center)
    best_tx = 0
    best_ty = 0
    x_range = range(-1*max_dp+offset[0], max_dp+offset[0]+1)
    y_range = range(-1*max_dp+offset[1], max_dp+offset[1]+1)
    for tx in x_range:
        for ty in y_range:
            # https://www.pyimagesearch.com/2021/02/03/opencv-image-translation/
            b_shifted = shift(b, tx, ty)
            b_center = subsample_center(b_shifted, ratio=0.8)
            error = ssd(a_center, b_center)
            #error = mse(a, b_shifted)
            #ab = cv.addWeighted(a, 0.5, b_shifted, 0.5, 0)
            #save_image(ab, stem, str(tx) + "x" + str(ty) + "_" + str(error))
            if error < best_error:
                best_error = error
                best_tx = tx
                best_ty = ty
    return best_tx, best_ty

def pyramid_align(a, b, stem, lim=400, max_dp=20):
    if VERBOSEP:
        print("aligning " + str(a.shape) + " channels")
    assert max_dp >= 0
    if lim < max_dp * 2:
        lim = max_dp * 2
    if a.shape[0] < lim or a.shape[1] < lim:        
        return exhaustive_align(a, b, stem, max_dp=max_dp)
    else:
        best_tx, best_ty = pyramid_align(half_size(a),
                                         half_size(b), stem,
                                         lim=lim, max_dp=max_dp)
        best_tx *= 2
        best_ty *= 2
        best_tx, best_ty = exhaustive_align(a, b, stem,
                                            max_dp=max_dp,
                                            offset=[best_tx, best_ty])
        return best_tx, best_ty
