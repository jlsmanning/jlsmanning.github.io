import cv2 as cv
import numpy as np

from helpers import *

def crop_white_border(img, stem, thresh=192, tar=255, ksize=5,
                      white=0.9):
    if VERBOSEP:
        print("cropping white border")
    assert 0 <= thresh <= 255
    assert 0 <= tar <= 255
    assert ksize % 2 == 1
    # blur to simplify image
    m = cv.medianBlur(img,5)
    # convert to black and white
    _, m = cv.threshold(m, thresh, tar, cv.THRESH_BINARY)
    # dilate whites so border is enhanced
    kernel = np.ones((ksize, ksize), np.uint8)
    m = cv.dilate(m, kernel, iterations=1)
    save_image(m, stem, "prep_cropwhite")
    # convert to floats
    m = to_float(m)
    # initialize bounds
    top = 0
    bottom = m.shape[0] - 1
    left = 0
    right = m.shape[1] - 1
    # collapse horizontally to find top and bottom borders
    a = m.sum(axis=1) / m.shape[1]
    while top <= bottom and a[top] >= white:
        top += 1
    while bottom >= top and a[bottom] >= white:
        bottom -= 1
    bottom += 1 # because range end non-inclusive
    # collapse vertically to find left and right borders
    a = m.sum(axis=0) / m.shape[0]
    while left <= right and a[left] >= white:
        left += 1
    while right >= left and a[right] >= white:
        right -= 1
    right += 1 # because range end non-inclusive
    # crop image using the obtained bounds
    img = img[top:bottom, left:right]
    save_image(img, stem, "after_cropwhite")
    return img

def crop_outer_black_border(img, stem, thresh=60, tar=255, ksize=5,
                            black=0.2):
    if VERBOSEP:
        print("cropping outer black border")
    assert 0 <= thresh <= 255
    assert 0 <= tar <= 255
    assert ksize % 2 == 1
    # erode so black border is enhanced
    kernel = np.ones((ksize, ksize), np.uint8)
    m = cv.erode(img, kernel, iterations=1)    
    # convert to black and white
    #m = cv.convertScaleAbs(m, alpha=2.0, beta=-100)
    _, m = cv.threshold(m, thresh, tar, cv.THRESH_BINARY)
    save_image(m, stem, "prep_cropblackouter")
    # convert to floats
    m = to_float(m)
    # initialize bounds
    top = 0
    bottom = m.shape[0] - 1
    left = 0
    right = m.shape[1] - 1
    # collapse horizontally to find top and bottom borders
    a = m.sum(axis=1) / m.shape[1]
    # skip over remnants of the white border to get to black
    # then find the end of the black area
    while top <= bottom and a[top] > black:
        top += 1
    while top <= bottom and a[top] <= black:
        top += 1
    while bottom >= top and a[bottom] > black:
        bottom -= 1
    while bottom >= top and a[bottom] <= black:
        bottom -= 1
    bottom += 1 # because range end non-inclusive
    # collapse vertically to find left and right borders
    a = m.sum(axis=0) / m.shape[0]
    # skip over remnants of the white border to get to black
    # then find the end of the black area
    while left <= right and a[left] > black:
        left += 1
    while left <= right and a[left] <= black:
        left += 1
    while right >= left and a[right] > black:
        right -= 1
    while right >= left and a[right] <= black:
        right -= 1
    right += 1 # because range end non-inclusive
    # crop image using the obtained bounds
    img = img[top:bottom, left:right]
    save_image(img, stem, "after_cropblackouter")
    return img

def crop_inner_black_border(img, stem, thresh=60, tar=255, ksize=3, black=0.075):
    if VERBOSEP:
        print("cropping inner black borders")
    assert ksize % 2 == 1
    # erode so black border is enhanced
    kernel = np.ones((ksize, ksize), np.uint8)
    m = cv.erode(img, kernel, iterations=1)
    # convert to black and white
    _, m = cv.threshold(m, thresh, tar, cv.THRESH_BINARY)
    save_image(m, stem, "prep_cropblackinner")
    # convert to floats
    m = to_float(m)
    # collapse horizontally
    a = m.sum(axis=1) / m.shape[1]
    # intialize border bounds
    b1_bottom = b2_top = m.shape[0] // 2
    # starting from the center find the upper border
    while b1_bottom >= 0 and a[b1_bottom] > black:
        b1_bottom -= 1
    b1_top = b1_bottom
    while b1_top >= 0 and a[b1_top] <= black:
        b1_top -= 1
    b1_top += 1 # put it back to black
    # starting from the center find the lower border
    while b2_top < m.shape[0] and a[b2_top] > black:
        b2_top += 1
    b2_bottom = b2_top
    while b2_bottom < m.shape[0] and a[b2_bottom] <= black:
        b2_bottom += 1
    b2_bottom -= 1 # put it back to black
    # remove the borders
    top = img[0:b1_top, :]
    middle = img[b1_bottom+1:b2_top, :]
    bottom = img[b2_bottom+1:, :]
    if 0 in top.shape or 0 in middle.shape or 0 in bottom.shape:
        print("Inner border crop failed")
        save_image(img, stem, "after_cropblackinner")
        return img
    # do a centered crop so they're all the same size
    smallest_h = min([top.shape[0], middle.shape[0],
                      bottom.shape[0]])
    d = (top.shape[0] - smallest_h) // 2
    top = top[d:d+smallest_h, :]
    d = (middle.shape[0] - smallest_h) // 2
    middle = middle[d:d+smallest_h, :]
    d = (bottom.shape[0] - smallest_h) // 2
    bottom = bottom[d:d+smallest_h, :]
    #show_three(top, middle, bottom)
    # recombine the parts into one image
    img = np.vstack((top, middle, bottom))
    save_image(img, stem, "after_cropblackinner")
    return img

def crop_displacement_stripes(b, g, r, bx, by, rx, ry):
    if VERBOSEP:
        print("cropping stripes caused by alignment displacement")
    x_d = max((abs(rx), abs(bx)))
    y_d = max((abs(ry), abs(by)))
    w = g.shape[1] - 2 * x_d
    h = g.shape[0] - 2 * y_d

    b = b[y_d:h, x_d:w]
    g = g[y_d:h, x_d:w]
    r = r[y_d:h, x_d:w]
    return b, g, r
