from helpers import *

def build(filename):
    stem = filename.split('.')[0]
    beg = "<!DOCTYPE html>\n<html>\n<body style=\"background-color:Gray\">\n"
    end = "</body>\n</html>"
    body = ""
    fig_start = "<figure>\n  <img src=\""
    fig_middle = "\">\n  <figcaption>"
    fig_end = "</figcaption>\n</figure>\n<br>\n"    

    body += fig_start + stem + '_orig.png' + fig_middle + 'The original image (' + filename + ')' + fig_end

    body += fig_start + stem + '_prep_cropwhite.png' + fig_middle + 'The image processed for cropping the white border' + fig_end

    body += fig_start + stem + '_after_cropwhite.png' + fig_middle + 'The image after cropping the white border' + fig_end

    body += fig_start + stem + '_prep_cropblackouter.png' + fig_middle + 'The image processed for cropping the outer black border' + fig_end

    body += fig_start + stem + '_after_cropblackouter.png' + fig_middle + 'The image after cropping the outer black border' + fig_end

    body += fig_start + stem + '_prep_cropblackinner.png' + fig_middle + 'The image processed for cropping the inner black borders' + fig_end

    body += fig_start + stem + '_after_cropblackinner.png' + fig_middle + 'The image after cropping the inner black borders' + fig_end

    body += fig_start + stem + '_before_align.png' + fig_middle + 'The image channels superimposed after cropping and before any alignment' + fig_end

    body += fig_start + stem + '_channels_edges.png' + fig_middle + 'The channels of the image processed to ease the alignment procedure' + fig_end

    body += fig_start + stem + '_aligned.png' + fig_middle + 'The image after the alignment procedure' + fig_end

    body += fig_start + stem + '_cropaligned.png' + fig_middle + 'The aligned image after cropping the borders formed by displacements of the channels' + fig_end

    body += fig_start + stem + '_final.png' + fig_middle + 'The final aligned and slightly enhanced image' + fig_end

    html_file = os.path.join(RESULTS_DIR, stem, "index.html")
    with open(html_file, "w") as f:
        f.write(beg + body + end)
    return html_file
