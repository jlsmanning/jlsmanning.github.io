import cv2 as cv
import matplotlib.pyplot as plt
import math
import numpy as np
import os

VERBOSEP = True
IMG_DIR = "data"
RESULTS_DIR = "results"

def get_files(which='all'):
    if which == 'test':
        return ['test_image.png',
                '00125v.jpg',
                '01861a.jpg']
    elif which == 'all':
        filenames = []
        for f in os.listdir(IMG_DIR):
            if f.endswith(('.jpg', '.png')):
                filenames.append(f)
        return filenames
    else:
        return []

def load_image(filename, colorp=False):
    # prepare results directory
    stem = filename.split(".")[0]
    # load image
    c = cv.IMREAD_GRAYSCALE if not colorp else cv.IMREAD_COLOR
    img = cv.imread(os.path.join(IMG_DIR, filename), c)
    return img, stem

def save_image(img, stem, name):
    results_path = os.path.join(RESULTS_DIR, stem)
    if not os.path.exists(results_path):
        os.makedirs(results_path)
    filename = os.path.join(results_path, stem + "_" + name + ".png")
    return cv.imwrite(filename, img)

def to_float(img):
    return img.astype(np.float32) / 255

def to_uint8(img):
    return (img * 255).astype(np.uint8)

def show_image(img):
    # does not normalize image
    if len(img.shape) == 2:
        plt.imshow(img, cmap='gray', vmin=0, vmax=255)
    else:
        plt.imshow(cv.cvtColor(img, cv.COLOR_BGR2RGB), vmin=0, vmax=255)
    plt.xticks([]), plt.yticks([]) 
    plt.axis('off')
    plt.show()

def pad_vertical(img, amt, val=0):
    # biassed towards adding padding to the bottom
    assert 0 <= val <= 255
    h1 = amt // 2
    h2 = amt - h1
    w = img.shape[1]
    pad1 = np.ones((h1,w)).astype(np.uint8) * val
    pad2 = np.ones((h2,w)).astype(np.uint8) * val
    img2 = np.vstack((pad1, img))
    img3 = np.vstack((img2, pad2))
    return img3

def crop_vertical(img, amt):
    # biassed towards cropping off the bottom
    h1 = amt // 2
    h2 = amt - h1
    return img[h1:img.shape[0]-h2, :]

def split_image(img):
    (b, g, r) = cv.split(img)
    return b, g, r

def merge_image(b, g, r):
    img = cv.merge([b, g, r])
    return img

def sidebyside(b, g, r, grayp=True):
    if grayp:
        img = np.hstack((b,g,r))
    else:
        empty = np.zeros(b.shape).astype(np.uint8)
        b = cv.merge([b, empty, empty])
        g = cv.merge([empty, g, empty])
        r = cv.merge([empty, empty, r])
        img = np.hstack((b,g,r))
    return img

def show_two(a, b, cmap='gray'):
    if cmap != 'gray':
        a = cv.cvtColor(a, cv.COLOR_BGR2RGB)
        b = cv.cvtColor(b, cv.COLOR_BGR2RGB)
    plt.axis("off")
    plt.subplot(1, 2, 1)
    plt.imshow(a, cmap=cmap, vmin=0, vmax=255)
    plt.subplot(1, 2, 2)
    plt.imshow(b, cmap=cmap, vmin=0, vmax=255)
    plt.show()

def show_three(a, b, c):
    plt.axis("off")
    plt.subplot(1, 3, 1)
    plt.imshow(a, cmap='gray', vmin=0, vmax=255)
    plt.subplot(1, 3, 2)
    plt.imshow(b, cmap='gray', vmin=0, vmax=255)
    plt.subplot(1, 3, 3)
    plt.imshow(c, cmap='gray', vmin=0, vmax=255)
    plt.show()

def normalize(m):
    # normalizes to 0.0:1.0
    min_val = m.min()
    max_val = m.max()
    return (m - min_val) / (max_val - min_val)

def ssd(a, b):
    #return sum(sum(pow((a - b), 2)))
    diff = a.ravel() - b.ravel()
    return np.sum(diff**2)

def mse(a, b):
    # a and b are 2d
    s = ssd(a, b)
    n = a.shape[0] * a.shape[1]
    return s/n

def shift(m, tx, ty):
    M = np.float32([
        [1, 0, tx],
        [0, 1, ty]
    ])
    return cv.warpAffine(m, M, (m.shape[1], m.shape[0]))

def subsample_center(m, ratio=0.5):
    h = math.floor(m.shape[0] * ratio)
    w = math.floor(m.shape[1] * ratio)
    top = (m.shape[0] - h) // 2
    bottom = top + h
    left = (m.shape[1] - w) // 2
    right = left + w
    return m[top:bottom, left:right]

def half_size(m):
    return cv.resize(m, None, fx=0.5, fy=0.5,
                     interpolation = cv.INTER_CUBIC)

def thirds(img):
    third = img.shape[0] // 3
    a = img[0:third, :]
    b = img[third:third*2, :]
    c = img[third*2:third*3, :] # discard last pixels
    return a, b, c
